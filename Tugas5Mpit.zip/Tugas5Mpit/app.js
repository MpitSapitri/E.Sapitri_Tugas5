let { sayHello, sayGoodbye } = require('./package/sayHello.js');
let { kmToMiles, celsiusToFahrenheit } = require('./package/konversi.js');
let { luasPersegi, luasPersegiPanjang } = require('./package/luaspersegi.js');
let { luasTrapesium, luasTrapesiumSikuSiku } = require('./package/luasTrapesium.js');

console.log(sayHello());
console.log(sayGoodbye());

let kilometers = 10;
let miles = kmToMiles(kilometers);
console.log(`${kilometers} km is equal to ${miles.toFixed(2)} miles.`);
let celsius = 25;
let fahrenheit = celsiusToFahrenheit(celsius);
console.log(`${celsius}°C is equal to ${fahrenheit.toFixed(2)}°F.`);

console.log(`Luas persegi dengan sisi 4: ${luasPersegi(4)}`);
console.log(`Luas persegi panjang dengan panjang 5 dan lebar 3: ${luasPersegiPanjang(5, 3)}`);

console.log(`Luas trapesium dengan sisi sejajar 5, 7, dan tinggi 4: ${luasTrapesium(5, 7, 4)}`);
console.log(`Luas trapesium siku-siku dengan sisi pendek 3, panjang 5, dan tinggi 4: ${luasTrapesiumSikuSiku(3, 5, 4)}`);