function luasTrapesium(sisiSejajar1, sisiSejajar2, tinggi) {
    return 0.5 * (sisiSejajar1 + sisiSejajar2) * tinggi;
  }
function luasTrapesiumSikuSiku(sisiPendek, sisiPanjang, tinggi) {
    return 0.5 * (sisiPendek + sisiPanjang) * tinggi;
  }
  
  module.exports = { luasTrapesium, luasTrapesiumSikuSiku };