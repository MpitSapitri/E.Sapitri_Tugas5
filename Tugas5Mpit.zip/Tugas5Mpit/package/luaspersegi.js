function luasPersegi(sisi) {
    return sisi * sisi;
  }
  function luasPersegiPanjang(panjang, lebar) {
    return panjang * lebar;
  }
  
  module.exports = { luasPersegi, luasPersegiPanjang };
  