function kmToMiles(km) {
    return km * 0.621371;
  }
  function celsiusToFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
  }
  
  module.exports = { kmToMiles, celsiusToFahrenheit };
  