function sayHello() {
    return "Hello from EnengSapitri";
  }
  function sayGoodbye() {
    return "Goodbye from EnengSapitri";
  }
  
  module.exports = { sayHello, sayGoodbye };
  